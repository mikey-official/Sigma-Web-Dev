// Particle.js Configuration
particlesJS('particles-js', {
    particles: {
        number: { value: 80 },
        color: { value: '#0ff' }, // Cyan color
        shape: { type: 'circle' },
        opacity: {
            value: 0.5,
            random: true
        },
        size: {
            value: 3,
            random: true
        },
        move: {
            enable: true,
            speed: 2,
            direction: 'none',
            random: true,
            out_mode: 'out'
        }
    }
});

// Custom Cursor
const cursor = document.querySelector('.cursor');
const cursorFollower = document.querySelector('.cursor-follower');

// Hide the default cursor
document.body.style.cursor = 'none';

// Check if cursor elements exist
if (cursor && cursorFollower) {
    document.addEventListener('mousemove', (e) => {
        requestAnimationFrame(() => {
            cursor.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
            cursorFollower.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
        });
    });
}

// Scroll Reveal Animation
gsap.registerPlugin(ScrollTrigger);

gsap.utils.toArray('.reveal').forEach(section => {
    gsap.from(section, {
        y: 50,
        opacity: 0,
        duration: 1,
        scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 50%',
            scrub: 1
        }
    });
});

// Tilt Effect for Project Cards
document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const xc = rect.width/2;
        const yc = rect.height/2;
        
        const dx = x - xc;
        const dy = y - yc;
        
        card.style.transform = `rotateY(${dx/10}deg) rotateX(${-dy/10}deg)`;
    });
    
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'rotateY(0) rotateX(0)';
    });
});

// Enhanced Hover Effects
document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const xc = rect.width/2;
        const yc = rect.height/2;
        
        const dx = x - xc;
        const dy = y - yc;
        
        const angle = Math.atan2(dy, dx);
        const distance = Math.sqrt(dx*dx + dy*dy);
        
        card.style.transform = `
            rotateY(${dx/10}deg) 
            rotateX(${-dy/10}deg)
            scale(1.05)
            translateZ(20px)
        `;
        
        card.style.setProperty('--glow-angle', `${angle}rad`);
        card.style.setProperty('--glow-distance', `${distance}px`);
    });
});

// Enhanced button interactions
document.querySelectorAll('.primary-btn, .secondary-btn').forEach(button => {
    button.addEventListener('mousemove', (e) => {
        const rect = button.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        button.style.setProperty('--x', `${x}px`);
        button.style.setProperty('--y', `${y}px`);
    });
});

document.addEventListener('DOMContentLoaded', () => {
    // Handle navigation clicks
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Side Navigation Toggle
    const hamburger = document.querySelector('.hamburger');
    const sideNav = document.querySelector('.side-nav');

    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        sideNav.classList.toggle('active');
    });

    // Close side nav when clicking links
    document.querySelectorAll('.side-nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            sideNav.classList.remove('active');
        });
    });

    // Close side nav when clicking outside
    document.addEventListener('click', (e) => {
        if (!sideNav.contains(e.target) && !hamburger.contains(e.target)) {
            hamburger.classList.remove('active');
            sideNav.classList.remove('active');
        }
    });

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-skill');
            }
        });
    });

    document.querySelectorAll('.skill-tag').forEach((tag) => {
        observer.observe(tag);
    });
});

// Smooth scroll for navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            const offset = 80; // Adjust for fixed navbar
            const targetPosition = targetElement.offsetTop - offset;
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
            
            // Add visual feedback
            const flash = document.createElement('div');
            flash.className = 'scroll-flash';
            targetElement.appendChild(flash);
            
            setTimeout(() => {
                flash.remove();
            }, 1000);
        }
    });
});

let lastScroll = 0;
const navbar = document.querySelector('.navbar');
const scrollThreshold = 100; // Minimum scroll before showing/hiding navbar

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    // Add scrolled class when page is scrolled
    if (currentScroll > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
    
    // Show/hide navbar based on scroll direction
    if (currentScroll > lastScroll && currentScroll > scrollThreshold) {
        // Scrolling down & past threshold - hide navbar
        navbar.classList.remove('visible');
    } else {
        // Scrolling up or at top - show navbar
        navbar.classList.add('visible');
    }
    
    lastScroll = currentScroll;
});