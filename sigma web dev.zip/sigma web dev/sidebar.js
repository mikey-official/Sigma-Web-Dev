document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.getElementById('hamburger-menu');
    const sideNav = document.querySelector('.side-nav');
    const sideNavLinks = document.querySelectorAll('.side-nav-links a');

    // Toggle sidebar
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        sideNav.classList.toggle('active');
    });

    // Close sidebar when clicking a link
    sideNavLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            sideNav.classList.remove('active');
        });
    });

    // Close sidebar when clicking outside
    document.addEventListener('click', (e) => {
        if (!sideNav.contains(e.target) && !hamburger.contains(e.target)) {
            hamburger.classList.remove('active');
            sideNav.classList.remove('active');
        }
    });

    // Close sidebar with ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && sideNav.classList.contains('active')) {
            hamburger.classList.remove('active');
            sideNav.classList.remove('active');
        }
    });
});
